import Foundation

class Solution {
    func removeDuplicates(_ nums: inout [Int]) -> Int {
        var index: Int = 0
        while index < nums.count - 1 {
            if nums[index] == nums[index+1] {
                nums.remove(at: index+1)
            } else {
                index += 1
            }
        }
        return nums.count
    }
    
    func reverseString(_ s: inout [Character]) {
        var left = 0
        var right = s.count - 1
        while (left < right) {
            let temp = s[left]
            s[left] = s[right]
            s[right] = temp
            
            left += 1
            right -= 1
        }
    }
     public class ListNode {
         public var val: Int
         public var next: ListNode?
         public init(_ val: Int) {
             self.val = val
             self.next = nil
         }
    }
    func removeNthFromEnd(_ head: ListNode?, _ n: Int) -> ListNode? {
        let firstListNode: ListNode = ListNode(head?.val ?? 0)
        firstListNode.next = head
        var currentListNode: ListNode = ListNode(firstListNode.val)
        currentListNode.next = firstListNode
        var length: Int = 1
        
        while currentListNode.next != nil {
            currentListNode = currentListNode.next!
            length += 1
        }
        
        currentListNode = firstListNode
        
        while length > 0 {
            currentListNode = (currentListNode.next ?? nil)!
            length -= 1
        }
        currentListNode.next = currentListNode.next?.next
        return head
    }
    public class TreeNode {
         public var val: Int
         public var left: TreeNode?
         public var right: TreeNode?
         public init(_ val: Int) {
             self.val = val
             self.left = nil
             self.right = nil
         }
     }
    func isValidBST(_ root: TreeNode?) -> Bool {
            return false
    }
    
    func merge(_ nums1: inout [Int], _ m: Int, _ nums2: [Int], _ n: Int) {
        var mm = 0
        var nn = 0
        var mergeArray: Array<Int> = Array()
        var count = 0
        
        
        while mm == nums1.count && nn == nums2.count {
            if nums1[mm] == 0 || nums2[nn] == 0{
                continue
            }
            if nums1[mm] < nums2[nn] {
                mergeArray[count] = nums1[mm]
                mm += 1
            } else {
                mergeArray[count] = nums2[nn]
                nn += 1
            }
            count += 1
        }
        print(mergeArray)
    }
    func climbStairs(_ n: Int) -> Int {
        if n == 1 {
            return 1
        }
        var first = 1, second = 2
        for _ in 3..<n+1 {
            let third = first + second
            first = second
            second = third
        }
        return second
    }
    
    func fizzBuzz(_ n: Int) -> [String] {
        var fizzBuzz: [String] = []
        
        for i in 0..<n {
            if i % 3 == 0 && i % 5 == 0 {
                fizzBuzz.append("FizzBuzz")
            } else if i % 3 == 0 && i % 5 != 0 {
                fizzBuzz.append("Fizz")
            } else if i % 3 != 0 && i % 5 == 0 {
               fizzBuzz.append("Fizz")
            } else {
                fizzBuzz.append("\(i)")
            }
        }
        return fizzBuzz
    }
    func sortColors(_ nums: inout [Int]) {
        
    }
    
    func findNumber(arr: [Int], k: Int) -> String {
        // Write your code here
        if arr.contains(k) {
            return "YES"
        } else {
            return "NO"
        }
    }
    
    func oddNumbers(l: Int, r: Int) -> [Int] {
        // Write your code here
        var oddNumbers: [Int] = []
        for i in l..<r+1 {
            if i % 2 != 0 {
                oddNumbers.append(i)
            }
        }
        return oddNumbers
    }
    
    
}

extension Array where Element == Int {
    
    /// Returns a decoded version of a delta encoded array
    public func deltaDecoded() -> [Element] {
        // please add your code here
        var deltaArray:[Element] = []
        
        for i in 0..<self.count {
            if i == 0 {
                deltaArray.append(self[i])
                print(self[i] )
            }
            if i > 0 && self[i] != -128 {
                deltaArray.append(self[i-1] + self[i+1])
                print(self[i] )
            }
        }
        return deltaArray
    }
    func test() {
        let testArray = [25626, -128, 131, -128, -1390, -100, -128, -24251, 84, -98, -128, 7275]
        testArray.deltaDecoded()
    }
}

extension String {
    /// Returns whether the string is a pangram or not
    public func isPangram() -> Bool {
        // Please add your code here
        let alphabet = "abcdefghijklmnopqrstuvwxyz"

        let chars = self.lowercased().filter { alphabet.contains($0) }
        return chars
            .reduce(into: Set()) { $0.insert($1) }
            .count == 26
    }
}
struct Price {
    let currency: String
    let basePrice: Int
}

guard let stdout = ProcessInfo.processInfo.environment["OUTPUT_PATH"] else { fatalError("Cannot create stdout") }
FileManager.default.createFile(atPath: stdout, contents: nil, attributes: nil)
guard let fileHandle = FileHandle(forWritingAtPath: stdout) else { fatalError("Cannot create output file") }
guard let input = readLine()?.trimmingCharacters(in: .whitespacesAndNewlines).components(separatedBy: " ").compactMap({ Int($0) }), input.count == 2 else { fatalError("Bad input") }
let result = Price(currency: "€", basePrice: input[0]).rounded(to: input[1])
fileHandle.write("\(result)".data(using: .utf8)!)

extension Price {

    /// Returns the base price rounded to the nearest multiple of 10ⁿ, where n = insignificantPlaces
    func rounded(to insignificantDigits: Int) -> Int {
        // please add your code here
        if insignificantDigits > 0 {
            return self.rounded(to: insignificantDigits)
        } else {
            let divisor = pow(10.0, Double(insignificantDigits))
            return Int((Double(self.basePrice) * divisor).rounded() / divisor)
        }
        return insignificantDigits
    }
}
struct PolygonCount {
    var rhombus: Int
    var parallelogram: Int
    var polygon: Int
    var invalid: Int
}

struct Solutionss {
    
    /// Provides a struct that contains the counts of squares, rectangles, and other polygons
    static func polygonCount(from lines: [String]) -> PolygonCount {
        // please add your code here
        var polygonCount: PolygonCount = PolygonCount(rhombus: 0, parallelogram: 0, polygon: 0, invalid: 0)
        if lines.count <= 0 {
            return polygonCount
        } else {
            for item in lines {
                let array = item.split(separator: " ")
                if array.count != 4 {
                    polygonCount.invalid += 1
                    continue
                }
                var hasInvalid: Bool = false
                
                for item in array {
                    if item.contains("-") {
                        polygonCount.invalid += 1
                        hasInvalid = true
                        break
                    }
                }
                if hasInvalid {
                    continue
                }
                
                if array[0] == array[1] && array[1] == array[2] && array[2] == array[3] {
                    polygonCount.rhombus += 1
                } else if array[0] == array[2] && array[1] == array[3]{
                    polygonCount.parallelogram += 1
                } else {
                    polygonCount.polygon += 1
                }
                
            }
            return polygonCount
        }
        
        
    }
}
