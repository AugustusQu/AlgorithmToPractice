//
//  ImageDownloader.swift
//  Moments
//
//  Created by Qu, Zhanxiang(AWF) on 2019/12/15.
//

import UIKit

class ImageDownloader: NSObject {
    
    private static let instance: ImageDownloader = ImageDownloader()
    
    class var sharedLoader: ImageDownloader {
        return instance
    }

    private var cache = NSCache<AnyObject, AnyObject>()
    
    private let filePath = "ImageCache"
    
    private func getFilePath() -> String {
        let paths = NSSearchPathForDirectoriesInDomains(.cachesDirectory, .userDomainMask, true)
        return (paths.first! as NSString).appendingPathComponent(filePath)
    }
    
    func imageForUrl(urlString: String, completionHandler:@escaping (_ image: UIImage?) -> ()) {
        
        let key = urlString.md5()
        
        DispatchQueue.global().async {
            
            //cache
            let data: Data? = self.cache.object(forKey: key as AnyObject) as? Data
            if let d = data {
                let image = UIImage(data: d as Data)
                DispatchQueue.main.async {
                    completionHandler(image)
                }
                return
            }
            
            //disk
            let filePath = self.getFilePath()
            let path = self.getFilePath()+"/"+key
            if let image = UIImage(contentsOfFile: path) {
                DispatchQueue.main.async {
                    completionHandler(image)
                }
                return
            }
            
            //download
            let downloadTask: URLSessionDataTask = URLSession.shared.dataTask(with: URL(string: urlString)!, completionHandler: { (data, response, error) in
                if (error != nil) {
                    completionHandler(nil)
                    return
                }
                if data != nil {
                    let image = UIImage(data: data!)
                    self.cache.setObject(data as AnyObject, forKey: key as AnyObject)
                    
                    let fileManager = FileManager.default
                    do {
                        try fileManager.createDirectory(at: URL(fileURLWithPath: filePath), withIntermediateDirectories: true, attributes: nil)
                        try data!.write(to: URL(fileURLWithPath: path))
                    }catch{
                        print(error)
                    }
                    
                    DispatchQueue.main.async {
                        completionHandler(image)
                    }
                    return
                }
            })
            downloadTask.resume()
        }
    }
}
