//
//  Moment.swift
//  Moments
//
//  Created by Qu, Zhanxiang(AWF) on 2019/12/8.
//

import Foundation
import UIKit

struct Moment : Hashable, Codable {

    let comments : [Commentator]?
    let content : String?
    let error : String?
    let images : [MomentImage]?
    let sender : Sender?
    let unknownerror : String?

    var cellHeight: CGFloat?
    

    enum CodingKeys: String, CodingKey {
        case comments = "comments"
        case content = "content"
        case cellHeight = "cellHeight"
        case error = "error"
        case images = "images"
        case sender
        case unknownerror = "unknown error"
    }



}
