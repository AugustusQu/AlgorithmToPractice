//
//  Commentator.swift
//  Moments
//
//  Created by Qu, Zhanxiang(AWF) on 2019/12/8.
//

import Foundation

struct Commentator : Hashable, Codable {

    let content : String?
    let sender : Sender?


    enum CodingKeys: String, CodingKey {
        case content = "content"
        case sender
    }
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        content = try values.decodeIfPresent(String.self, forKey: .content)
        sender = try Sender(from: decoder)
    }


}
