//
//  User.swift
//  Moments
//
//  Created by Qu, Zhanxiang(AWF) on 2019/12/8.
//

import Foundation

struct User : Hashable, Codable {

    let avatar : String?
    let nick : String?
    let profileimage : String?
    let username : String?


    enum CodingKeys: String, CodingKey {
        case avatar = "avatar"
        case nick = "nick"
        case profileimage = "profile-image"
        case username = "username"
    }
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        avatar = try values.decodeIfPresent(String.self, forKey: .avatar)
        nick = try values.decodeIfPresent(String.self, forKey: .nick)
        profileimage = try values.decodeIfPresent(String.self, forKey: .profileimage)
        username = try values.decodeIfPresent(String.self, forKey: .username)
    }

}
