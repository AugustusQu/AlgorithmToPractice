//
//  Sender.swift
//  Moments
//
//  Created by Qu, Zhanxiang(AWF) on 2019/12/8.
//

import Foundation

import Foundation

struct Sender : Hashable, Codable {

    let avatar : String?
    let nick : String?
    let username : String?


    enum CodingKeys: String, CodingKey {
        case avatar = "avatar"
        case nick = "nick"
        case username = "username"
    }
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        avatar = try values.decodeIfPresent(String.self, forKey: .avatar)
        nick = try values.decodeIfPresent(String.self, forKey: .nick)
        username = try values.decodeIfPresent(String.self, forKey: .username)
    }


}
