//
//  ImagesView.swift
//  Moments
//
//  Created by Qu, Zhanxiang(AWF) on 2019/12/8.
//

import UIKit


class ImagesView: UIView {
    
    func configImages(images : [MomentImage]) -> CGFloat {
        // remove all subviews
        self.removeAllImages()
        
        
        let imageCount = images.count
        let padding: CGFloat = 5.0
        let imageContentViewWidth: CGFloat = UIScreen.main.bounds.size.width - 132
        let  imageWidth: CGFloat = (imageContentViewWidth - padding * 2.0) / 3.0
        let imageHeight: CGFloat = imageWidth
        
        for i in 0...imageCount-1 {
            let imageView = UIImageView()
            let imageX: CGFloat = (padding + imageWidth) * CGFloat((i % 3))
            let imageY: CGFloat = (padding + imageHeight) * CGFloat((i / 3))
            imageView.frame = CGRect(x: imageX, y: imageY, width: imageWidth, height: imageHeight)
            
            //set image
            if let imageUrl:String = images[i].url {
                ImageDownloader.sharedLoader.imageForUrl(urlString: imageUrl) { (image) in
                    imageView.image = image
                }
            }
            
            self.addSubview(imageView)
            imageView.tag = i
            
        }
        
        var height: CGFloat = 0.0
        if imageCount == 0 {
            height = 0
        }else if (imageCount > 0 && imageCount <= 3){
            height = imageHeight
        }else if (imageCount > 3 && imageCount <= 6){
            height = imageHeight * 2 + padding
        }else{
            height = imageHeight * 3 + padding * 2
        }
        
        return height
    }
    public func removeAllImages() {
        self.subviews.forEach({ $0.removeFromSuperview() })
    }
}
