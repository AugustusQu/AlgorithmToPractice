//
//  TweetTableViewCell.swift
//  Moments
//
//  Created by Qu, Zhanxiang(AWF) on 2019/12/8.
//

import UIKit

class TweetTableViewCell: UITableViewCell {

    var moment: Moment? 
    @IBOutlet weak var momentAvatar: UIImageView!
    @IBOutlet weak var momentName: UILabel!
    @IBOutlet weak var momentContent: UILabel!
    
    @IBOutlet weak var imagesView: ImagesView!
    @IBOutlet weak var imagesViewHeightConstraints: NSLayoutConstraint!
    
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var commentsStackView: CommentsStackView!
    
    @IBOutlet weak var commentsStackViewHeightConstraint: NSLayoutConstraint!

    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    func configerCell(indexPath: IndexPath) -> CGFloat{
        
        guard moment != nil else {
            return 0
        }
        if let avtarUrl: String = moment?.sender?.avatar {
            ImageDownloader.sharedLoader.imageForUrl(urlString: avtarUrl) { (image) in
                self.momentAvatar.image = image
            }
        }
        
        
        if let username: String = moment?.sender?.username {
            momentName?.text = username
        }
        momentName?.sizeToFit()
        if let content: String = moment?.content {
            momentContent?.text = content
        }
        momentContent?.sizeToFit()
    
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM-dd-yyyy"
        dateLabel?.text = dateFormatter.string(from: Date())
        
        var imagesHeight: CGFloat = 0
        
        if moment?.images?.count ?? 0 > 0 {
             //images
            imagesHeight = imagesView.configImages(images: (moment?.images ?? nil)!)
        } else {
            imagesView.removeAllImages()
        }
        self.imagesViewHeightConstraints.constant = imagesHeight
       
        //comments

        if moment?.comments?.count ?? 0 > 0 {
            commentsStackView.comments = moment?.comments

            self.commentsStackViewHeightConstraint.constant = CGFloat((moment?.comments?.count ?? 0) * 20)
        } else {
            self.commentsStackViewHeightConstraint.constant = 0
        }
                
        self.layoutSubviews()

        //total height
        let labelsHeight: CGFloat = (momentName?.frame.height ?? 18.0) + (momentContent?.frame.height ?? 21.0) + 25
        
        moment?.cellHeight = 53 + labelsHeight + imagesHeight + self.commentsStackViewHeightConstraint.constant
        
        
        return moment?.cellHeight ?? 200
    }
    

    

    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
