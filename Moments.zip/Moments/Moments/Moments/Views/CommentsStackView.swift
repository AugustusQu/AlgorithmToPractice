//
//  CommentsStackView.swift
//  Moments
//
//  Created by Qu, Zhanxiang(AWF) on 2019/12/22.
//

import UIKit

class CommentsStackView: UIStackView {
        var comments : [Commentator]? {
        didSet {
            
            for commentator in (self.comments ?? nil)! {
                let commentsLabel: UILabel = UILabel.init()
                commentsLabel.numberOfLines = 0
                commentsLabel.sizeToFit()
                commentsLabel.text = commentator.sender?.username ?? "" + (commentator.content)!
                self.addArrangedSubview(commentsLabel)
            }
        }
    }
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
