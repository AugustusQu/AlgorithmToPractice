//
//  MomentsTableViewController.swift
//  Moments
//
//  Created by Qu, Zhanxiang(AWF) on 2019/12/8.
//

import UIKit


class MomentsTableViewController: UITableViewController {
    static let refreshCount: Int = 5
    var isPullDownRefresh: Bool = false
    var isPullUpRefresh: Bool = false
    
    var user: User?
    var moments: [Moment]?
    
    var cellHeightForRow: Dictionary<String, Any>?
    
    
    @IBOutlet weak var profileImage: UIImageView!
    @IBOutlet weak var username: UILabel!
    @IBOutlet weak var avatar: UIImageView!
    
//    @IBOutlet weak var footerActivityIndicatorView: UIActivityIndicatorView!
    
    let spinner = UIActivityIndicatorView()

    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
        self.refreshControl = UIRefreshControl()
        refreshControl?.addTarget(self, action: #selector(pullDownRefresh), for: UIControl.Event.valueChanged)
        
        spinner.frame = CGRect(x: CGFloat(0), y: CGFloat(0), width: tableView.bounds.width, height: CGFloat(44))
        self.tableView.tableFooterView?.addSubview(spinner)
        
        fetchUserData()
        fetchTweetsData()
        
    }
    
    // MARK: - User refresh action.
    @objc func pullDownRefresh() {
        isPullDownRefresh = true
        isPullUpRefresh = false
        fetchTweetsData()
    }
    
    @objc func pullUpRefresh() {
        isPullDownRefresh = false
        isPullUpRefresh = true
        fetchTweetsData()
    }
    
    
    // MARK: - Data flow action.
    
    func fetchUserData() {
        let Url = String(format: "https://thoughtworks-mobile-2018.herokuapp.com/user/jsmith")
        guard let serviceUrl = URL(string: Url) else { return }
        let request = URLRequest(url: serviceUrl)
        
        NetworkManager().sessionTaskWith(request: request) { (json, response, error) in
            do {
                guard let responseDict = json as? [String: AnyObject] else {
                    print("Invalid Response")
                    return
                }
                let jsonResponse = try JSONSerialization.data(withJSONObject: responseDict, options: .prettyPrinted)
            
                let decoder = JSONDecoder()
                self.user = try decoder.decode(User.self, from: jsonResponse)
                self.configerUserInfo()
            } catch {
                print("Decoder error:", error)
            }
        }
    }
    @objc func fetchTweetsData() {
        
        
        let Url = String(format: "https://thoughtworks-mobile-2018.herokuapp.com/user/jsmith/tweets")
        guard let serviceUrl = URL(string: Url) else { return }
        let request = URLRequest(url: serviceUrl)
        
        NetworkManager().sessionTaskWith(request: request) { (json, response, error) in
            self.refreshControl?.endRefreshing()
            self.spinner.stopAnimating()
            
            do {
                guard let responseDict = json as? [AnyObject] else {
                    print("Invalid Response")
                    return
                }
                let jsonResponse = try JSONSerialization.data(withJSONObject: responseDict, options: .prettyPrinted)
                
            
                let decoder = JSONDecoder()
                let moments = try decoder.decode([Moment].self, from: jsonResponse)
                let momentsResponse = moments.filter{ $0.unknownerror == nil }
                if self.isPullDownRefresh {
                    if momentsResponse.count > MomentsTableViewController.refreshCount {
                        self.moments?.insert(contentsOf: momentsResponse.prefix(MomentsTableViewController.refreshCount), at: 0)
                    } else {
                        self.moments?.insert(contentsOf: momentsResponse, at: 0)
                    }
                } else if self.isPullUpRefresh {
                    if momentsResponse.count > MomentsTableViewController.refreshCount {
                        self.moments? += momentsResponse.prefix(MomentsTableViewController.refreshCount)
                    } else {
                        self.moments? += momentsResponse
                    }
                } else {
                    self.moments = momentsResponse
                }
                
                self.tableView.reloadData()
            } catch {
                print("Decoder error:", error)
            }
        }
    }
    // MARK: - Configer view
    func configerUserInfo() {
        if let profileimageUrl: String = user?.profileimage {
            ImageDownloader.sharedLoader.imageForUrl(urlString: profileimageUrl) { (image) in
                self.profileImage.image = image
            }
        }
        if let avtarUrl: String = user?.avatar {
            ImageDownloader.sharedLoader.imageForUrl(urlString: avtarUrl) { (image) in
                self.avatar.image = image
            }
        }
        username.text = user?.username
    }
    
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.moments?.count ?? 0
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: TweetTableViewCell = tableView.dequeueReusableCell(withIdentifier: "TweetTableViewCell", for: indexPath) as! TweetTableViewCell

        // Configure the cell...
        var moment = self.moments?[indexPath.row]
        cell.moment = moment
        
        moment?.cellHeight = cell.configerCell(indexPath: indexPath)
        self.moments?[indexPath.row] = moment!
        self.cellHeightForRow?.updateValue(NSNumber.init(value: Float(moment?.cellHeight ?? 200.0)), forKey: String(indexPath.hashValue))

        return cell
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        

        let moment = self.moments?[indexPath.row]

        return moment?.cellHeight ?? 200
        

    }

    
    // MARK: - Table view data delegate
    //cache row height
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        let lastSectionIndex = tableView.numberOfSections - 1
        let lastRowIndex = tableView.numberOfRows(inSection: lastSectionIndex) - 1
        if indexPath.section ==  lastSectionIndex && indexPath.row == lastRowIndex {
           spinner.startAnimating()
           spinner.translatesAutoresizingMaskIntoConstraints = false

           pullUpRefresh()
        }
    }

    /*
    override func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        let cell: TweetTableViewCell = TweetTableViewCell()
        var moment = self.moments?[indexPath.row]
        moment?.cellHeight = cell.configerCell()

        return moment?.cellHeight ?? 150
    }
*/
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
