//
//  NetworkManager.swift
//  Moments
//
//  Created by Qu, Zhanxiang(AWF) on 2019/12/8.
//

import Foundation
typealias NetworkRequestCompletion = ((_ jsonResponse:Any?,_ urlResponse:URLResponse?, _ error:Error?) -> Void)

class NetworkManager: NSObject {
    // MARK: - Networking request.
    func sessionTaskWith(request: URLRequest,completion:@escaping NetworkRequestCompletion){
        URLSession.shared.dataTask(with: request) { (data, response, error) in

            if let responsedata = data {
                do {
                    let json = try JSONSerialization.jsonObject(with: responsedata, options: [])
                    print(json)
                    
                    DispatchQueue.main.async {
                        completion(json, response, error)
                    }
                } catch {
                    print(error)
                    completion(nil, response, error)
                }
            }
        }.resume()
    }
}
